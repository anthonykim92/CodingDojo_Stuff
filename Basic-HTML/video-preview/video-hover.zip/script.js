function playvideo(vid){
    vid.play()
}
    


function pausevideo(vid) {
    vid.pause()
}