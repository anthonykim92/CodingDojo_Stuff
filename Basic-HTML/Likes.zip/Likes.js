var likeSpan1 = document.querySelector("#post-1")
function plusone(){
var value_= likeSpan1.innerText ++}

var likeSpan2 = document.querySelector("#post-2")
function plustwo(){
var value_= likeSpan2.innerText ++}

var likeSpan3 = document.querySelector("#post-3")
function plusthree(){
var value_= likeSpan3.innerText ++}